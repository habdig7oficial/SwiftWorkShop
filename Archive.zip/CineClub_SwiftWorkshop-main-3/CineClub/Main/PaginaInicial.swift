//
//  PaginaInicial.swift
//  CineClub
//
//  Created by Aluno Mack on 07/10/24.
//

import SwiftUI

struct PaginaInicial: View {
    var body: some View {
        
        ZStack{
            Color("BackgroundColor").ignoresSafeArea()
             
            var text_size: CGFloat = 25
             VStack{
                 
                 var img_size: CGFloat = 168
                 Image("CineClubLogo")
                     .resizable()
                     .frame(width: img_size, height: img_size)
                     .clipShape(Circle())

                 Text("O lugar ideal para busscar, salvar, seus filmes favoritos!")
                     .foregroundColor(.white)
                     .font(.system(size: text_size))
                     .bold()
                     .multilineTextAlignment(.center)

                
                 Button{
                     print("Hello")
                 }
                 label: {
                     Text("Gambiarra")
                         //.foregroundStyle(.black)
                         .font(.system(size: text_size))
                         .foregroundColor(.white)
                         //.background(.blue)
                         .padding(.horizontal, 10)
                         .bold()
                         .padding(.horizontal, 10)
                         .padding(.vertical, 15)
                         .background(Color("YellowButtonColor"))
                         .clipShape(RoundedRectangle(cornerRadius: 32))
                 }
                 
                 // .
                 
             }

        }
        
        
    }
}

struct PaginaInicial_Previews: PreviewProvider {
    static var previews: some View {
        PaginaInicial()
    }
}
