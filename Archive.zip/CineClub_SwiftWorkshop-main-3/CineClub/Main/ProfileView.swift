//
//  ProfileView.swift
//  CineClub
//
//  Created by Aluno Mack on 07/10/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        ZStack{
            Color("BackgroundColor")
            
                .ignoresSafeArea() /* cor de fundo preta */
            
            VStack(alignment: .leading){
                
                
                VStack(spacing: 50){
                    HStack{
                        Text("Lorem Ipsum")
                            .foregroundColor(.pink)
                            .bold()
                            .italic()
                            .font(.system(size: 50))
                        Spacer()
                    }
                    
                    var dimension: CGFloat = 168
                    
                    
                    Image("perfil-coelho")
                        .resizable()
                        .frame(width: dimension, height: dimension)
                        .clipShape(Circle())
                    
                    
                    
                    Text("Dolor Sit Amed")
                        .foregroundColor(.white)
                        .bold()
                        .font(.system(size: 24))
                    
                    
                    var my_size: CGFloat = 20
                    HStack{
                        Text("Hello")
                            .foregroundColor(.blue)
                            .font(.system(size: my_size))
                        
                        Text("World")
                            .foregroundColor(.yellow)
                            .font(.system(size: my_size))
                    }.padding(.vertical, 10)
                    
                    var lero_lero = "Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nam congue sapien sit amet justo egestas congue. Maecenas ut pellentesque arcu. Integer tempor urna nec est feugiat, sit amet pretium nibh venenatis. Sed finibus turpis turpis, ut scelerisque enim sollicitudin a. Praesent a mi dui. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed condimentum tellus ut ornare tempor. Nulla bibendum eros non pharetra luctus. Integer maximus justo id urna porttitor lobortis. Nam quis viverra orci. Praesent gravida libero a purus ullamcorper luctus. Morbi sed egestas neque, a dignissim elit."
                    
                    Text(lero_lero)
                        .foregroundColor(.gray)
                        .font(.system(size: my_size - 0.5))
                    
                    
                    Spacer()
                    
                }
                
            }
            
        }
        
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
