//
//  CineClubApp.swift
//  CineClub
//
//  Created by Giovanna Micher on 02/10/24.
//

import SwiftUI

@main
struct CineClubApp: App {
    var body: some Scene {
        WindowGroup {
                //ContentView()
                PaginaInicial()
        }
    }
}
